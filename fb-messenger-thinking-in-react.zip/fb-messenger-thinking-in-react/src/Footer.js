import React from 'react'

const Footer = (props) => (
  <div className="footer">
    ReactJS Academy
  </div>
)

export default Footer
