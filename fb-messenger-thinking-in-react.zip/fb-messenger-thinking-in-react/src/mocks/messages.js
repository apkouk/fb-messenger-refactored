const messages = [
    {
        "from": "crazypeacock512",
        "to":"you",
        "time":"2018-02-11T12:00:00Z",
        "message":"Hey, how is it going?"
    },
    {
        "from": "you",
        "to":"crazygorilla163",
        "time":"2018-02-10T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"crazypeacock512",
        "time":"2018-02-10T11:30:00Z",
        "message":"message text"
    },
    {
        "from": "crazygorilla163",
        "to":"you",
        "time":"2018-02-10T10:33:00Z",
        "message":"message text"
    },
    {
        "from": "silverfish61",
        "to":"you",
        "time":"2018-02-10T08:00:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"silverfish61",
        "time":"2018-02-01T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"silverfish61",
        "time":"2017-12-10T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"silverfish61",
        "time":"2017-12-09T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"silverfish61",
        "time":"2017-12-01T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"silverfish61",
        "time":"2017-11-10T12:33:00Z",
        "message":"message text"
    },
    {
        "from": "heavygoose106",
        "to":"you",
        "time":"2017-11-10T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"heavygoose106",
        "time":"2017-12-10T11:05:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"heavygoose106",
        "time":"2017-12-10T09:33:00Z",
        "message":"message text"
    },
    {
        "from": "blueelephant847",
        "to":"you",
        "time":"2017-12-08T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "blueelephant847",
        "to":"you",
        "time":"2017-12-06T11:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"blueelephant847",
        "time":"2017-12-06T09:33:00Z",
        "message":"message text"
    },
    {
        "from": "you",
        "to":"silverfish61",
        "time":"2017-12-05T19:33:00Z",
        "message":"message text"
    }
]

export default messages