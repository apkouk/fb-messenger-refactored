const users = [
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "mary",
      "last": "jones"
    },
    "email": "mary.jones56@example.com",
    "username": "crazypeacock512"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "alan",
      "last": "walters"
    },
    "email": "alan.walters29@example.com",
    "username": "crazytiger134"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "miriam",
      "last": "wallace"
    },
    "email": "miriam.wallace36@example.com",
    "username": "blackpanda974"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "annette",
      "last": "black"
    },
    "email": "annette.black70@example.com",
    "username": "greenelephant690"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "joshua",
      "last": "pearson"
    },
    "email": "joshua.pearson33@example.com",
    "username": "bluebutterfly167"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "willard",
      "last": "barrett"
    },
    "email": "willard.barrett17@example.com",
    "username": "redfrog150"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "lucy",
      "last": "hansen"
    },
    "email": "lucy.hansen42@example.com",
    "username": "bluesnake414"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "johnni",
      "last": "franklin"
    },
    "email": "johnni.franklin85@example.com",
    "username": "biglion303"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "kenneth",
      "last": "warren"
    },
    "email": "kenneth.warren82@example.com",
    "username": "goldenkoala804"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "sergio",
      "last": "ryan"
    },
    "email": "sergio.ryan90@example.com",
    "username": "smallsnake403"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "michael",
      "last": "hart"
    },
    "email": "michael.hart69@example.com",
    "username": "browndog574"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "judd",
      "last": "steeves"
    },
    "email": "judd.steeves56@example.com",
    "username": "purpleswan777"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "aiden",
      "last": "peterson"
    },
    "email": "aiden.peterson83@example.com",
    "username": "crazypanda94"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "edwin",
      "last": "morales"
    },
    "email": "edwin.morales41@example.com",
    "username": "bigkoala328"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "gail",
      "last": "holmes"
    },
    "email": "gail.holmes71@example.com",
    "username": "silvertiger605"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "jackie",
      "last": "medina"
    },
    "email": "jackie.medina91@example.com",
    "username": "bigladybug498"
  },
  {
    "gender": "female",
    "name": {
      "title": "mrs",
      "first": "anita",
      "last": "turner"
    },
    "email": "anita.turner36@example.com",
    "username": "silverdog296"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "oscar",
      "last": "wells"
    },
    "email": "oscar.wells37@example.com",
    "username": "whitedog307"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "george",
      "last": "young"
    },
    "email": "george.young96@example.com",
    "username": "whiteduck952"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "wyatt",
      "last": "nelson"
    },
    "email": "wyatt.nelson81@example.com",
    "username": "lazymeercat254"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "ian",
      "last": "west"
    },
    "email": "ian.west17@example.com",
    "username": "tinyduck707"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "felix",
      "last": "miles"
    },
    "email": "felix.miles29@example.com",
    "username": "blackdog881"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "lloyd",
      "last": "herrera"
    },
    "email": "lloyd.herrera71@example.com",
    "username": "blueelephant847"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "toni",
      "last": "obrien"
    },
    "email": "toni.obrien19@example.com",
    "username": "bluebear73"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "kelly",
      "last": "shaw"
    },
    "email": "kelly.shaw12@example.com",
    "username": "blackgorilla589"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "darryl",
      "last": "hopkins"
    },
    "email": "darryl.hopkins33@example.com",
    "username": "bigbear866"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "arthur",
      "last": "ferguson"
    },
    "email": "arthur.ferguson86@example.com",
    "username": "crazygorilla163"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "rachel",
      "last": "garrett"
    },
    "email": "rachel.garrett39@example.com",
    "username": "silverfish61"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "freddie",
      "last": "matthews"
    },
    "email": "freddie.matthews37@example.com",
    "username": "yellowgorilla642"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "calvin",
      "last": "freeman"
    },
    "email": "calvin.freeman62@example.com",
    "username": "heavygoose106"
  }
]

export default users